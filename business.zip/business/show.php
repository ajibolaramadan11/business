<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="sel.css">
</head>
<body>
    <h1><?php echo $_SESSION['name'];?></h1>
<div id="cart" class="cart">
<?php
    include ('config.php');

    $email = $_SESSION['email'];

    $getprod="SELECT * FROM cart where email = '$email'";
    $que=mysqli_query($connection,$getprod);
    while($row=mysqli_fetch_array($que)){?>
     <div class="fisr">
         <div class="cart_image">
                <img src="imgb/<?php echo $row['product_img'] ;?>"alt="Carts Product Image">
         </div>
        <div class="cart_details">
            <p name="sp"><b>Product Name: </b><?php echo $row['product_name'];?></p>
            <p name="fp"><b>Price: </b>#<?php echo $row['product_price']; ?></p>
            <p name="fp"><b>Quantity: </b><?php echo $row['quantity']; ?></p>
        </div>
    </div>
<?php
    }
?>
</div>
</body>
</html>