<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="sel.css">
</head>
<body>
<!-- <a href="login.php" class="logout">log out</a> -->
 <div class="conta">
    <?php
    include ('config.php');
    //  $_SESSION['name']=$name;
    //  echo "<h1>$name</h1>";
    ?>
    <?php
    $getprod="SELECT * FROM buztab";
    $que=mysqli_query($connection,$getprod);
    while($row=mysqli_fetch_array($que)){?>
     <div class="fisr">
         <div class="fistp">
                <img src="imgb/<?php echo $row['imgf'] ;?>"alt="oo">
         </div>
            <div class="twop">
                <p name="sp"><?php echo $row['product'];?></p>
                <p name="fp"><?php echo "# ". $row['price']; ?></p>
            </div>
            <div class="afc">
                <form action="#" method="post">
                <input type="hidden" value="<?php echo $row['id'];?>" name="sn">
                <input type="hidden" value="<?php echo $row['product'];?>" name="product">
                <input type="hidden" value="<?php echo  $row['price'];?>" name="price">
                <input type="hidden" value="<?php echo $row['imgf'];?>" name="imgf">
                <input type="number" name="quantity" placeholder="how many....">
                <a href="edit.php?id=<?php echo $row['id'];?>">edit</a>
                <?php
                if(!isset($_SESSION['email'])){ 
                    if(isset($_POST['log'.$row['id']])){
                        echo "<script> alert('login to add to cart') ;
                        location.href='login.php';
                         </script>";
                    }
                    ?>
                     <input type="submit" value="add cart" name="log<?php echo $row['id']  ?>">
                     
                <?php
                }else{
                   echo' <input type="submit" value="add cart" name="submit">';
                }
                 ?>
                
            </form>
            </div>
        </div>
        <?php } ?>
        
        <?php

                if(isset($_POST['submit'])){
                    $product_id = $_POST['sn'];
                    $product_name = $_POST['product'];
                    $product_price = $_POST['price'];
                    $product_img = $_POST['imgf'];
                    $quantity = $_POST['quantity'];
                    $email = $_SESSION['email'];
                    $status = 0;
                    $insert = "INSERT INTO cart(product_id, product_name, product_price, product_img, quantity,email,status) VALUE('$product_id', '$product_name', '$product_price', '$product_img', '$quantity','$email','$status')";
                    $query= mysqli_query($connection,$insert);
                    if($query){
                       echo"<script>location.href='show.php'</script>";
                    }else{
                        // header("location: index.php");
                        echo "Something went wrong";
                    }
                }
            
                ?>    
</div>
</body>
</html>
