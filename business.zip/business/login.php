<?php session_start() ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business || Login</title>
    <!-- <link rel="stylesheet" href="sel.css"> -->
    <style>
        .container{
           gap:20px;
           background-color:green;
           /* padding: -20%; */
           width:20%;
           margin:25%;
           padding: 5%;
           border-radius:30px;
        }
        body{
            background-color:darkgray;
        }
        input{
            background-color:white;
            border-radius:8px 13px;
            padding: 9px;
            font-weight:bold;
            border:none;
        }
        a:link{
            text-decoration:none;
        }
        .slb{
            background-color:darkgray;
            padding: 5px;
            border-radius:7px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form">
            <form action="" method="post">
              <input type="email" name="email" placeholder="your email..."><br><br>
              <input type="password" name="password" placeholder="your password..." ><br><br>
              <button type="submit" name="submit">Login</button>
            </form>
        </div>
        <p>or</p>
        <a href="signup.php" class="slb">sign up</a>
    </div>
</body>
</html>


<?php

include ('config.php');

if(isset($_POST['submit'])){
 $email = $_POST['email'];
 $password = $_POST['password'];

 $select = mysqli_query($connection, 
 "SELECT * FROM signup WHERE email = '$email' AND pwd = '$password' ");
 $row = mysqli_fetch_array($select);


if($row){
  $_SESSION['email'] = $email;
    
        header('location:index.php');
    
    }
    else{
        echo "incorrect email or password";
    }
   
}



?>