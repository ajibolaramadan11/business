<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="sel.css">
</head>
<body style=" background-image: url(prodimg.jpg);">
  <div class="alla">
    <form action="#" method="post" enctype="multipart/form-data">
    <input type="text" placeholder="product name....." name="pron"><br><br>
    <input type="text" placeholder="price of product......." name="price"><br><br>
    <input type="text" placeholder="quantity...." name="qty"><br><br>
    <input type="file" placeholder="input file" name="file[]" required multiple><br><br>
    <input type="submit" value="submit" name="submit" class="subb">
</form>
</div>
</body>
</html>
<?php include("config.php"); ?>

<?php
if(isset($_POST["submit"])){
  $pron= $_POST['pron'];
  $price= $_POST['price'];
  $qty= $_POST['qty'];
  $file= $_FILES["file"]["name"];
  $fold="imgb/";

  // count $file to enable us select multiple files
  $count = count($file);
  for ($i=0; $i<$count; $i++){
  $filename = $_FILES["file"]["name"][$i];
  $findest= $fold.$filename;
  $tmpname= $_FILES["file"]["tmp_name"][$i];

  $ins="INSERT INTO buztab(product, price, quantity, imgf)
   VALUES ('$pron','$price','$qty', '$filename')";
    $con = mysqli_query($connection, $ins);

     
  }
  if(move_uploaded_file($tmpname, $findest)){
    echo "successfully uploaded";
 }
 else {
    echo "error";
 }
 
  };
?>