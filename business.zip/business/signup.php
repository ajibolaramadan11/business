<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="sel.css"> -->
    <style>
        body {
            background-color: gray;
        }
        .sec2{
            margin:25%;
            padding:10%;
            background-color:yellowgreen;
            border-radius:20px;
            text-align:center;
        }
        input{
            border:none;
            padding:10px;
            border-radius:5px;
        }
    </style>
</head>
<body>
    <div class="sec2">
    <form action="#" method="post">
        <input type="text" name="name" placeholder="your legal name..." required><br><br>
        <input type="text" name="username" placeholder="Username...." required><br><br>
        <input type="email" name="email" placeholder="your email @...." required><br><br>
        <input type="date" name="dob" required><br><br>
        <input type="password" name="pwd" placeholder="your password..." required><br><br>
        <input type="submit" name="submit" value="submit">
        <p>or</p>
        <a href="login.php">login</a>
        <br>
        
      
    </div>
    <?php
    include('config.php');
    if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $username=$_POST['username'];
        $email=$_POST['email'];
        $dob=$_POST['dob'];
        $pwd=$_POST['pwd'];
        $select="SELECT * FROM signup WHERE email = '$email'";
        $selquery= mysqli_query ($connection,$select);
        $num= mysqli_num_rows($selquery);
        $_SESSION['name']=$name;
        if($num > 0){
            echo "email already exist";
        }
        else{
        $ins="INSERT INTO signup(name,username,email,dob,pwd) VALUE('$name','$username','$email','$dob','$pwd')";
        $que=mysqli_query($connection,$ins);
        if($que){
header('location:login.php');                }
        else{
            echo "error";
        }
    }
    }
    ?>
</body>
</html>