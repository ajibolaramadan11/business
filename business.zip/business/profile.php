<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>profile</title>
</head>
<body>
    <div class="profile">
        <?php
        include('config.php');
        $email=$_SESSION['email'];
        $sel="SELECT * FROM signup WHERE email='$email'";
        $que=mysqli_query($connection,$sel);
        while($row=mysqli_fetch_array($que)){?>
       <label for="name">Name:</label> <p><?php echo $row['name'] ;?></p>
       <p><?php echo $row['username'] ;?></p>
       <p><?php echo $row['email'] ;?></p>
      
        <?php
        }
        ?>
    </div>
</body>
</html>