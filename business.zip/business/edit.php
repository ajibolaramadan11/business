<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php
include('config.php');
$proid=$_GET['id'];
// echo $proid;
$sel=mysqli_query($connection, "SELECT * FROM buztab WHERE id='$proid'");
while($row=mysqli_fetch_array($sel)){?>
    <form action="#" method="post">
    <!-- <input type="text" name="pimg" value="<?php echo $row['imgf'];?>"> -->
    <input type="text" name="pname" value="<?php echo $row['product'];?>">
    <input type="text" name="pprice" value="<?php echo $row['price'];?>">
    <input type="submit" name="submit" value="submit">
    </form>
    <?php
    if(isset($_POST["submit"])){
        $pname=$_POST['pname'];
        $pprice=$_POST['pprice'];
        $update=mysqli_query($connection,"UPDATE buztab SET product='$pname',price='$pprice' WHERE id=$proid ");
        if($update){
            echo "successfully update";

        }else{
            echo "error";
        }
    }
    ?>
    <!-- <img src="imgb/<?php echo $row['imgf'];?>" alt="">
    <p><?php echo $row['product'];?></p>
    <p><?php echo $row['price'];?></p> -->
<?php
}
?>